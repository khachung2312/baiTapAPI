const { response } = require('express')
const express = require('express')

const app = express()
const mysql = require('mysql2')
app.use(express.json())

const port = 4000
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '04082004',
    database: 'Phim'
})

connection.connect()

app.get('/', (request, response) => {
    response.send("Hello")
})
app.get('/users', (request, response) => {
    connection.query("SELECT * FROM BANG_NGUOI_DUNG", (err, data) => {
        if (err) {
            response.send("Co loi!")
        } else {
            response.send(data)
        }
    })
})

app.post('/users', (request, response) => {
    connection.query("INSERT INTO BANG_NGUOI_DUNG(`ID_NGUOI_DUNG`, `HO_TEN`, `SO_DIEN_THOAI`, `GIOI_TINH` ) VALUES (?, ?, ?, ?)", [
        request.body.ID_NGUOI_DUNG, request.body.HO_TEN, request.body.SO_DIEN_THOAI, request.body.GIOI_TINH
    ], (err) => {
        if (err) {
            response.send(err)
        } else {
            response.send("Them thanh cong!")
        }
    })
})


app.put('/user', (request, response) => {
    
    connection.query('UPDATE `BANG_NGUOI_DUNG` SET  `HO_TEN`=(?),`SO_DIEN_THOAI`=(?),`GIOI_TINH`=(?) WHERE `ID_NGUOI_DUNG` = (?)', 
    [ request.body.HO_TEN, request.body.SO_DIEN_THOAI, request.body.GIOI_TINH, request.body.ID_NGUOI_DUNG], 
    (err) => {
    if (err) {
        response.send(err);
        console.log("error")
    } else {
        response.send("Sua thanh cong!");
    }
    })
})


app.put('/film', (request, response) => {
    connection.query('UPDATE `BANG_PHIM` SET `TEN_PHIM`=(?),`THE_LOAI`=(?),`DANH_MUC`=(?),`NGAY_SAN_XUAT`=(?),`GIA_PHIM`=(?) WHERE `ID_PHIM` = (?)', 
    [ request.body.TEN_PHIM, request.body.THE_LOAI,request.body.DANH_MUC, request.body.NGAY_SAN_XUAT, request.body.GIA_PHIM, request.body.ID_PHIM], (err) => {
    if (err) {
        response.send(err);
    } else {
        response.send("Sua thanh cong!");
    }
    })
})

app.delete('/user/:id', (request, response) => {
    connection.query("DELETE FROM BANG_NGUOI_DUNG WHERE ID_NGUOI_DUNG = (?)", [
        request.params.id
    ], (err) => {
        if (err) {
            response.send(err)
        } else {
            response.send("Xoa thanh cong!")
        }
    })
})


app.listen(port, () => {
    console.log("Server API dang chay o cong 3000");
})

